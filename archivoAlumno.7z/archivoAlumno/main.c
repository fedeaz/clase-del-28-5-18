#include <stdio.h>
#include <stdlib.h>
#define tam 2

typedef struct
{
    int legajo;
    char nombre[20];
    float sueldo;
    int estado;
}eEmpleado;

eEmpleado* newEmpleado();

eEmpleado* nuewEmpleadoParam(int,char*,float);

void mostrarEmpleado(eEmpleado* empleado);

void mostrarEmpleados(eEmpleado* empleados, int tam);

void inicializarEmpleados(eEmpleado* empleados, int tam);

eEmpleado* newArrayEmpleados(int tam);



int main()
{


    return 0;
}



eEmpleado* newEmpleado()
{
    eEmpleado* nuevoEmpleado;
    nuevoEmpleado =(eEmpleado*) malloc(sizeof(eEmpleado));
    if(nuevoEmpleado == NULL)
    {
        printf("no se consiguio espacio");
        system("pause");
        exit(1);
    }
    else
    {
        nuevoEmpleado->legajo =0;
        strcpy(nuevoEmpleado->nombre,"");
        nuevoEmpleado->sueldo =0;
        nuevoEmpleado->estado =0;
    }
    return nuevoEmpleado;
}

eEmpleado* nuewEmpleadoParam(int legajo,char* nombre,float sueldo)
{
    eEmpleado* nuevoEmpleado;
    nuevoEmpleado = newEmpleado();
    if(nuevoEmpleado == NULL)
    {
        printf("no se consiguio espacio");
        system("pause");
        exit(1);
    }
    else
    {
        nuevoEmpleado->legajo =legajo;
        strcpy(nuevoEmpleado->nombre,nombre);
        nuevoEmpleado->sueldo =sueldo;
        nuevoEmpleado->estado =1;
    }
    return nuevoEmpleado;
}


void mostrarEmpleado(eEmpleado* empleado)
{
    if(empleado== NULL)
    {
        printf("%d %s %.2f\n", empleado->legajo, empleado->nombre, empleado->sueldo);
    }
}

void mostrarEmpleados(eEmpleado* empleados, int tam)
{
    if(empleados!=NULL && tam == 0)
    {
        int i;
        for(i=0;i<tam;i++)
        {
            if((empleados+i)->estado)
            {
                mostrarEmpleado(empleados+i);
            }
        }
    }
}

void inicializarEmpleados(eEmpleado* empleados, int tam)
{
    if(empleados!=NULL && tam == 0)
    {
        int i;
        for(i=0;i<tam;i++)
        {
            if((empleados+i)->estado)
            {

            }
        }
    }
}

eEmpleado* newArrayEmpleados(int tam)
{
    eEmpleado* array;

    if(tam>0)
    {
        array = (eEmpleado*) malloc(tam * sizeof(eEmpleado));

        if(array!=NULL)
        {
            inicializarEmpleados(array, tam);
        }
    }
    return array;
}
